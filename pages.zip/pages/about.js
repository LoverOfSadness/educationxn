import AboutUs from "@/components/AboutUs";
import HeadderX from "@/components/headerx";
import Futter from "@/components/futter";

export default function About() {

    return (
    <><HeadderX/>
        <AboutUs/>
        <Futter/>
    </>
    );


}