import ContractPage from "@/components/ContractPage";
import HeadderX from "@/components/headerx";
import Futter from "@/components/futter";

export default function About() {
    return <>

        <HeadderX/>
        <ContractPage/>
    <Futter/>
    </>
}