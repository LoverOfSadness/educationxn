//
// function fun1(calbk) {
//     console.log("im inside fun1");
//     let y=8+9;
//     calbk(y);
//     console.log("fun2 has end")
// }



function fun2(r) {

    console.log(r);


}


let tx=()=>{



};


console.log(tx)